## 1.1.6
- Added condition for if player is already wearing an item. (Idk why I didnt account for this lol)

## 1.1.5
- Changed how unwearing works for readability

## 1.1.4
- Fixed logger error
- Removed discard override
- Published to NuGet

## 1.1.3
- Added logic for unwearing item when item is discarded

## 1.1.2
- Added LICENSE
- Added website link to github

## 0.1.1
- Added github and discord links to README

## 0.1.0
- Initial release